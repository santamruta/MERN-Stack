const sequelize = require('./config/database');
const Transaction = require('./models/Transaction');

const populateData = async () => {
  await sequelize.sync({ force: true }); // This will drop the existing table and recreate it
  await Transaction.bulkCreate([
    { category: 'Food', amount: 50, date: new Date('2023-01-10') },
    { category: 'Clothing', amount: 150, date: new Date('2023-01-15') },
    { category: 'Electronics', amount: 300, date: new Date('2023-01-20') },
    { category: 'Food', amount: 80, date: new Date('2023-01-25') },
    // Add more sample transactions as needed
  ]);
  console.log('Sample data populated.');
};

populateData().catch(err => console.error('Error populating data:', err));
