const express = require('express');
const cors = require('cors');
const sequelize = require('./config/database');
const transactionRoutes = require('./routes/transactionRoutes');

const app = express();

app.use(cors());
app.use(express.json());
app.use('/api', transactionRoutes);

const PORT = process.env.PORT || 3001;

sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log('Database connected...');
  });
}).catch(err => {
  console.error('Error connecting to the database:', err);
});
