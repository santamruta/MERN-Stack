// // controllers/statisticsController.js

// const mysql = require('mysql');

// // Create MySQL connection
// const connection = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: 'amukt@123',
//   database: 'transactionsdb'
// });

// // Connect to MySQL
// connection.connect();

// exports.getMarchStatistics = (req, res) => {
//   // MySQL query to retrieve statistics for March
//   const query = `
//     SELECT 
//       SUM(amount) AS totalSaleAmount,
//       COUNT(*) AS totalTransactions,
//       SUM(CASE WHEN sold = 1 THEN 1 ELSE 0 END) AS totalSoldItems,
//       SUM(CASE WHEN sold = 0 THEN 1 ELSE 0 END) AS totalNotSoldItems
//     FROM transactions
//     WHERE MONTH(dateOfSale) = 3;`;

//   // Execute the query
//   connection.query(query, (error, results) => {
//     if (error) {
//       console.error('Error fetching March statistics:', error);
//       res.status(500).json({ message: 'Internal Server Error' });
//     } else {
//       res.json(results[0]); // Assuming only one row is returned
//     }
//   });
// };

// server.js

const express = require('express');
const mysql = require('mysql');

const app = express();

// Create MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'amukt@123',
  database: 'transactionsdb'
});

// Connect to MySQL
connection.connect();

// Endpoint to fetch statistics for March
app.get('/api/statistics/march', (req, res) => {
  // MySQL query to get statistics for March
  const query = `
    SELECT 
      SUM(amount) AS total_sale_amount,
      COUNT(*) AS total_transactions,
      SUM(CASE WHEN sold = 1 THEN 1 ELSE 0 END) AS total_sold_items,
      SUM(CASE WHEN sold = 0 THEN 1 ELSE 0 END) AS total_not_sold_items
    FROM transactions
    WHERE MONTH(date) = 3;`;

  // Execute the query
  connection.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching March statistics:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results[0]); // Assuming only one row is returned
    }
  });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

