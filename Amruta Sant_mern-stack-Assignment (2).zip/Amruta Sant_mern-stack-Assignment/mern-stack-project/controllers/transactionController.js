const Transaction = require('../models/Transaction');
const sequelize = require('../config/database');

exports.getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.findAll();
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
};

exports.getStatistics = async (req, res) => {
  try {
    // Implement your logic here
    res.json({ message: 'Statistics data' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
};

exports.getBarChart = async (req, res) => {
  try {
    const { month } = req.query;
    const transactions = await Transaction.findAll({
      where: sequelize.where(sequelize.fn('MONTH', sequelize.col('dateOfSale')), month)
    });

    const ranges = [
      { range: '0-100', min: 0, max: 100, count: 0 },
      { range: '101-200', min: 101, max: 200, count: 0 },
      { range: '201-300', min: 201, max: 300, count: 0 },
      // Add more ranges as needed
    ];

    transactions.forEach(transaction => {
      const price = transaction.price;
      ranges.forEach(range => {
        if (price >= range.min && price <= range.max) {
          range.count += 1;
        }
      });
    });

    res.json(ranges);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bar chart data' });
  }
};

exports.getPieChart = async (req, res) => {
  try {
    const { month } = req.query;
    const transactions = await Transaction.findAll({
      where: sequelize.where(sequelize.fn('MONTH', sequelize.col('dateOfSale')), month)
    });

    const categories = {};
    transactions.forEach(transaction => {
      const category = transaction.category;
      if (!categories[category]) {
        categories[category] = 0;
      }
      categories[category] += 1;
    });

    const pieData = Object.keys(categories).map(category => ({
      category,
      count: categories[category]
    }));

    res.json(pieData);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch pie chart data' });
  }
};
