// routes/statisticsRoutes.js

const express = require('express');
const router = express.Router();
const statisticsController = require('../controllers/statisticsController');

router.get('/march', statisticsController.getMarchStatistics);

module.exports = router;
