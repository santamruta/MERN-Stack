import React, { useState, useEffect } from 'react';
import axios from '../api/axiosConfig';
import { Bar } from 'react-chartjs-2';
import 'chart.js/auto';
import './Charts.css';

const TransactionsBarChart = () => {
  const [barData, setBarData] = useState([]);
  const [month, setMonth] = useState('1'); // Default to January

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('/bar-chart', { params: { month } });
        console.log('Bar chart data:', response.data); // Add console log
        setBarData(response.data);
      } catch (error) {
        console.error('Error fetching bar chart data:', error);
      }
    };
    fetchData();
  }, [month]);

  const data = {
    labels: barData.map(item => item.range),
    datasets: [{
      label: 'Number of Transactions',
      data: barData.map(item => item.count),
      backgroundColor: 'rgba(75, 192, 192, 0.6)',
    }],
  };

  return (
    <div className="chart-container">
      <h2>Bar Chart for {new Date(0, month - 1).toLocaleString('default', { month: 'long' })}</h2>
      <div className="button-container">
        {Array.from({ length: 12 }, (_, i) => (
          <button key={i + 1} onClick={() => setMonth(i + 1)}>
            {new Date(0, i).toLocaleString('default', { month: 'short' })}
          </button>
        ))}
      </div>
      <div style={{ width: '80%', height: '400px' }}> {/* Adjust width and height as needed */}
        <Bar data={data} />
      </div>
    </div>
  );
};

export default TransactionsBarChart;
