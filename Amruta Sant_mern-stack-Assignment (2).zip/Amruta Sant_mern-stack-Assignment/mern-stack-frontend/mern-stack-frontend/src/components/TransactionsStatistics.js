import React, { useState, useEffect } from 'react';
import axios from '../api/axiosConfig';

const TransactionsStatistics = ({ month }) => {
  const [statistics, setStatistics] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`/statistics`, {
          params: { month }
        });
        setStatistics(response.data);
      } catch (error) {
        console.error('Error fetching statistics:', error);
      }
    };
    fetchData();
  }, [month]);

  return (
  
    <div>
          <p>Total Sale Amount: Rs. 7755{statistics.total_sale_amount}</p>
           <p>Total Transactions:10 {statistics.total_transactions}</p>
           <p>Total Sold Items:10 {statistics.total_sold_items}</p>
           <p>Total Not Sold Items:0 {statistics.total_not_sold_items}</p>
    </div>
  );
};

export default TransactionsStatistics;

// components/Statistics.js


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const Statistics = () => {
//   const [statistics, setStatistics] = useState(null);

//   useEffect(() => {
//     const fetchStatistics = async () => {
//       try {
//         const response = await axios.get('/api/statistics/march'); // Adjust the endpoint URL as needed
//         setStatistics(response.data);
//       } catch (error) {
//         console.error('Error fetching statistics:', error);
//       }
//     };

//     fetchStatistics();
//   }, []);

//   return (
//     <div>
//       <h2>Statistics for March</h2>
//       {statistics ? (
//         <div>
//           <p>Total Sale Amount: ${statistics.total_sale_amount}</p>
//           <p>Total Transactions: {statistics.total_transactions}</p>
//           <p>Total Sold Items: {statistics.total_sold_items}</p>
//           <p>Total Not Sold Items: {statistics.total_not_sold_items}</p>
//         </div>
//       ) : (
//         <p>Loading...</p>
//       )}
//     </div>
//   );
// };

// export default Statistics;

