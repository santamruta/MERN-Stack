import React, { useState } from 'react';
import TransactionsTable from './components/TransactionsTable';
import TransactionsStatistics from './components/TransactionsStatistics';
import TransactionsBarChart from './components/TransactionsBarChart';
import TransactionsPieChart from './components/TransactionsPieChart';


const App = () => {
  const [month, setMonth] = useState('March');

  return (
    
    <div>
      <h1>Transaction Dashboard</h1>
      <select onChange={e => setMonth(e.target.value)} value={month}>
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        {/* Add other months */}
      </select>
      <TransactionsStatistics month={month} />
      <TransactionsBarChart month={month} />
      <TransactionsPieChart month={month} />
      <TransactionsTable />
    </div>
    
  );
  
};

export default App;
